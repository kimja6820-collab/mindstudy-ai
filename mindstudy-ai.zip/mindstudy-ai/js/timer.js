// ==========================================================================
// timer.js — จับเวลาอ่านหนังสือ, สลับโหมด, บันทึกลง study_sessions,
// และเรียกมินิเกมช่วงพัก
// ==========================================================================

const TIMER_MODES = {
  pomodoro: { label: "Pomodoro (25/5)", studyMin: 25, breakMin: 5 },
  "60_5": { label: "อ่าน 60 / พัก 5", studyMin: 60, breakMin: 5 },
  custom: { label: "กำหนดเอง", studyMin: 45, breakMin: 10 },
};

let timerState = {
  mode: "pomodoro",
  phase: "study", // 'study' | 'break'
  secondsLeft: TIMER_MODES.pomodoro.studyMin * 60,
  running: false,
  intervalId: null,
  subject: "",
  elapsedStudySeconds: 0,
};

function formatTime(totalSeconds) {
  const m = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const s = Math.floor(totalSeconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

function setTimerMode(modeKey, customStudyMin, customBreakMin) {
  timerState.mode = modeKey;
  if (modeKey === "custom" && customStudyMin) {
    TIMER_MODES.custom.studyMin = customStudyMin;
    TIMER_MODES.custom.breakMin = customBreakMin || 10;
  }
  timerState.phase = "study";
  timerState.secondsLeft = TIMER_MODES[modeKey].studyMin * 60;
  timerState.elapsedStudySeconds = 0;
}

/**
 * เริ่ม/หยุดชั่วคราวตัวจับเวลา
 * onTick(secondsLeft, phase) เรียกทุกวินาที
 * onPhaseEnd(phase) เรียกเมื่อช่วงเวลานั้นจบลง (study→break, break→study)
 */
function toggleTimer(onTick, onPhaseEnd) {
  if (timerState.running) {
    clearInterval(timerState.intervalId);
    timerState.running = false;
    return false;
  }
  timerState.running = true;
  timerState.intervalId = setInterval(() => {
    timerState.secondsLeft--;
    if (timerState.phase === "study") timerState.elapsedStudySeconds++;

    onTick(timerState.secondsLeft, timerState.phase);

    if (timerState.secondsLeft <= 0) {
      const endedPhase = timerState.phase;
      if (endedPhase === "study") {
        timerState.phase = "break";
        timerState.secondsLeft = TIMER_MODES[timerState.mode].breakMin * 60;
      } else {
        timerState.phase = "study";
        timerState.secondsLeft = TIMER_MODES[timerState.mode].studyMin * 60;
      }
      onPhaseEnd(endedPhase);
    }
  }, 1000);
  return true;
}

function resetTimer() {
  clearInterval(timerState.intervalId);
  timerState.running = false;
  timerState.phase = "study";
  timerState.secondsLeft = TIMER_MODES[timerState.mode].studyMin * 60;
  timerState.elapsedStudySeconds = 0;
}

/** บันทึก session การอ่านหนังสือที่ทำสำเร็จลง Supabase */
async function saveStudySession(userId, subject, durationMinutes, mode) {
  if (durationMinutes < 1) return; // ไม่บันทึกถ้าอ่านไม่ถึง 1 นาที
  const { error } = await supabaseClient.from("study_sessions").insert({
    user_id: userId,
    subject: subject || "ไม่ระบุวิชา",
    duration_minutes: Math.round(durationMinutes),
    mode,
    study_date: new Date().toISOString().slice(0, 10),
  });
  if (error) throw error;
}
