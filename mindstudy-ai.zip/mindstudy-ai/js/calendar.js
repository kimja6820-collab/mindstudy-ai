// ==========================================================================
// calendar.js — ปฏิทินวางแผนการเรียน: render เดือน, เพิ่ม/แก้ไข/ลบ event
// ==========================================================================

const THAI_MONTHS = [
  "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน",
  "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม",
];
const THAI_WEEKDAYS = ["อา", "จ", "อ", "พ", "พฤ", "ศ", "ส"];

let calendarState = {
  year: new Date().getFullYear(),
  month: new Date().getMonth(), // 0-indexed
  events: [], // แถวจาก planner_events
};

function toDateKey(y, m, d) {
  return `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

/** ดึง events ทั้งหมดของผู้ใช้จาก Supabase */
async function loadPlannerEvents(userId) {
  const { data, error } = await supabaseClient
    .from("planner_events")
    .select("*")
    .eq("user_id", userId)
    .order("event_date", { ascending: true });
  if (error) throw error;
  calendarState.events = data;
  return data;
}

async function addPlannerEvent(userId, title, eventDate, startTime, endTime) {
  const { error } = await supabaseClient.from("planner_events").insert({
    user_id: userId,
    title,
    event_date: eventDate,
    start_time: startTime || null,
    end_time: endTime || null,
    is_completed: false,
  });
  if (error) throw error;
}

async function updatePlannerEvent(eventId, fields) {
  const { error } = await supabaseClient.from("planner_events").update(fields).eq("id", eventId);
  if (error) throw error;
}

async function deletePlannerEvent(eventId) {
  const { error } = await supabaseClient.from("planner_events").delete().eq("id", eventId);
  if (error) throw error;
}

function eventsForDate(dateKey) {
  return calendarState.events.filter((e) => e.event_date === dateKey);
}

/** สร้างโครงสร้างข้อมูลของแต่ละวันในเดือนที่แสดง เพื่อนำไป render เป็น DOM เอง */
function buildMonthGrid(year, month) {
  const firstDay = new Date(year, month, 1).getDay(); // 0-6
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) {
    const dateKey = toDateKey(year, month, d);
    cells.push({ day: d, dateKey, events: eventsForDate(dateKey) });
  }
  return cells;
}

function changeMonth(delta) {
  calendarState.month += delta;
  if (calendarState.month > 11) {
    calendarState.month = 0;
    calendarState.year++;
  } else if (calendarState.month < 0) {
    calendarState.month = 11;
    calendarState.year--;
  }
}
