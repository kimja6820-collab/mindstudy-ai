// ==========================================================================
// stats.js — คำนวณสถิติเวลาอ่านหนังสือ: วันนี้ / สัปดาห์นี้ / สูงสุด / ต่ำสุด
// ==========================================================================

function getStartOfWeek() {
  const now = new Date();
  const day = now.getDay(); // 0 = อาทิตย์
  const diff = now.getDate() - day;
  const start = new Date(now.setDate(diff));
  start.setHours(0, 0, 0, 0);
  return start.toISOString().slice(0, 10);
}

/** ดึง study_sessions ทั้งหมดของผู้ใช้ แล้วคำนวณสถิติสรุป */
async function getStudyStats(userId) {
  const { data, error } = await supabaseClient
    .from("study_sessions")
    .select("duration_minutes, study_date")
    .eq("user_id", userId);
  if (error) throw error;

  const today = new Date().toISOString().slice(0, 10);
  const weekStart = getStartOfWeek();

  const todayTotal = data
    .filter((s) => s.study_date === today)
    .reduce((sum, s) => sum + s.duration_minutes, 0);

  const weekTotal = data
    .filter((s) => s.study_date >= weekStart)
    .reduce((sum, s) => sum + s.duration_minutes, 0);

  const durations = data.map((s) => s.duration_minutes);
  const maxSession = durations.length ? Math.max(...durations) : 0;
  const minSession = durations.length ? Math.min(...durations) : 0;

  return {
    todayTotal,
    weekTotal,
    maxSession,
    minSession,
    totalSessions: data.length,
  };
}
