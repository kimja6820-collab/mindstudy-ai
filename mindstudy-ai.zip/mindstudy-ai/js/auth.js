// ==========================================================================
// auth.js — สมัครสมาชิก / เข้าสู่ระบบ / ออกจากระบบ / ป้องกันหน้า (AuthGuard)
// ==========================================================================

/** สมัครสมาชิกด้วยอีเมล + รหัสผ่าน */
async function registerUser(email, password, displayName) {
  const { data, error } = await supabaseClient.auth.signUp({
    email,
    password,
    options: { data: { display_name: displayName || email.split("@")[0] } },
  });
  if (error) throw error;
  return data;
}

/** เข้าสู่ระบบด้วยอีเมล + รหัสผ่าน */
async function loginUser(email, password) {
  const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

/** เข้าสู่ระบบด้วย Google OAuth */
async function loginWithGoogle() {
  const { data, error } = await supabaseClient.auth.signInWithOAuth({
    provider: "google",
    options: { redirectTo: window.location.origin + "/dashboard.html" },
  });
  if (error) throw error;
  return data;
}

/** ออกจากระบบ แล้วกลับไปหน้าแรก */
async function logoutUser() {
  await supabaseClient.auth.signOut();
  window.location.href = "index.html";
}

/** คืนค่า session ปัจจุบัน (หรือ null ถ้ายังไม่ล็อกอิน) */
async function getCurrentUser() {
  const { data } = await supabaseClient.auth.getSession();
  return data.session ? data.session.user : null;
}

/**
 * เรียกใช้ในทุกหน้าที่ต้องล็อกอินก่อนถึงจะเข้าได้
 * ถ้ายังไม่ล็อกอิน จะเด้งกลับไปหน้า index.html ทันที
 */
async function authGuard() {
  const user = await getCurrentUser();
  if (!user) {
    window.location.href = "index.html";
    return null;
  }
  const nameEl = document.querySelectorAll("[data-user-name]");
  nameEl.forEach((el) => {
    el.textContent = user.user_metadata?.display_name || user.email;
  });
  return user;
}

/** แสดงข้อความ error/success ทั่วไปในกล่องฟอร์ม */
function showAuthMessage(elementId, message, isError = true) {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.textContent = message;
  el.classList.remove("hidden");
  el.classList.toggle("text-rose-600", isError);
  el.classList.toggle("text-emerald-600", !isError);
}
