// ==========================================================================
// Supabase configuration
// แก้ไข URL และ ANON KEY ให้ตรงกับโปรเจกต์ Supabase ของคุณ
// หาได้จาก Supabase Dashboard > Project Settings > API
// ==========================================================================

const SUPABASE_URL = "https://YOUR-PROJECT-REF.supabase.co";
const SUPABASE_ANON_KEY = "YOUR-SUPABASE-ANON-KEY";

// ใช้ supabase-js ที่โหลดจาก CDN ในแต่ละหน้า (ดู <script> ใน HTML)
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
