# MindStudy AI

ระบบวางแผนการเรียนและดูแลสุขภาพจิตนักศึกษา — HTML + Tailwind CSS (CDN) + Vanilla JS + Supabase

## โครงสร้างไฟล์
```
mindstudy-ai/
├── index.html          หน้าเข้าสู่ระบบ / สมัครสมาชิก / Google Auth
├── dashboard.html       แบบประเมินความเครียด + สรุปสถิติการอ่านหนังสือ
├── timer.html           จับเวลาอ่านหนังสือ (Pomodoro / 60-5 / กำหนดเอง) + มินิเกมช่วงพัก
├── minigame.html        ห้องมินิเกม (จับคู่การ์ด, Tic-Tac-Toe)
├── calendar.html        ปฏิทินวางแผนการเรียน/ตารางสอบ
├── style.css            ธีมสี ตัวอักษร และคอมโพเนนต์ที่ใช้ร่วมกันทุกหน้า
├── supabase-schema.sql  SQL สร้างตาราง + Row Level Security
├── js/
│   ├── supabase-config.js
│   ├── auth.js
│   ├── stress.js
│   ├── timer.js
│   ├── stats.js
│   └── calendar.js
```

## เริ่มต้นใช้งาน

1. **สร้างโปรเจกต์ Supabase** ที่ https://supabase.com
2. เปิด **SQL Editor** แล้ววางเนื้อหาไฟล์ `supabase-schema.sql` ทั้งหมด รันคำสั่ง
3. ไปที่ **Authentication > Providers** เปิดใช้งาน Email และ (ถ้าต้องการ) Google OAuth
4. ไปที่ **Project Settings > API** คัดลอก `Project URL` และ `anon public key`
5. เปิดไฟล์ `js/supabase-config.js` แล้วแทนที่ค่า:
   ```js
   const SUPABASE_URL = "https://YOUR-PROJECT-REF.supabase.co";
   const SUPABASE_ANON_KEY = "YOUR-SUPABASE-ANON-KEY";
   ```
6. เปิด `index.html` ในเบราว์เซอร์ (หรือใช้ Live Server) เพื่อทดสอบ

## Deploy ขึ้น Vercel
1. Push โฟลเดอร์นี้ขึ้น GitHub repository
2. ที่ https://vercel.com กด **New Project** แล้วเลือก repo นี้
3. เนื่องจากเป็น static site ล้วน ไม่ต้องตั้งค่า Build Command — ปล่อยว่างหรือเลือก "Other" เป็น Framework Preset
4. กด Deploy

## หมายเหตุด้านความปลอดภัย
- ทุกตาราง (`stress_logs`, `study_sessions`, `planner_events`) เปิด Row Level Security และมี policy ให้แต่ละผู้ใช้เห็นเฉพาะข้อมูลของตัวเอง (`auth.uid() = user_id`)
- Anon key ปลอดภัยที่จะฝังในฝั่ง client ได้ตามมาตรฐานของ Supabase เพราะสิทธิ์การเข้าถึงข้อมูลจริงถูกควบคุมด้วย RLS
