-- ==========================================================================
-- MindStudy AI — Supabase schema
-- รันสคริปต์นี้ใน Supabase Dashboard > SQL Editor
-- ==========================================================================

-- 1) stress_logs: บันทึกผลแบบประเมินความเครียด
create table if not exists stress_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  stress_score int not null check (stress_score in (25, 50, 75, 100)),
  ai_advice text,
  created_at timestamptz not null default now()
);

-- 2) study_sessions: บันทึกเซสชันการอ่านหนังสือ
create table if not exists study_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null default 'ไม่ระบุวิชา',
  duration_minutes int not null check (duration_minutes > 0),
  mode text not null check (mode in ('pomodoro', '60_5', 'custom')),
  study_date date not null default current_date,
  created_at timestamptz not null default now()
);

-- 3) planner_events: กิจกรรม/ตารางสอบในปฏิทิน
create table if not exists planner_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  event_date date not null,
  start_time time,
  end_time time,
  is_completed boolean not null default false,
  created_at timestamptz not null default now()
);

-- ดัชนีช่วยให้ query ตามผู้ใช้และวันที่เร็วขึ้น
create index if not exists idx_stress_logs_user on stress_logs(user_id, created_at desc);
create index if not exists idx_study_sessions_user_date on study_sessions(user_id, study_date);
create index if not exists idx_planner_events_user_date on planner_events(user_id, event_date);

-- ==========================================================================
-- Row Level Security: แยกข้อมูลตามบัญชีผู้ใช้ (auth.uid() = user_id)
-- ==========================================================================

alter table stress_logs enable row level security;
alter table study_sessions enable row level security;
alter table planner_events enable row level security;

-- stress_logs policies
create policy "select own stress_logs" on stress_logs for select using (auth.uid() = user_id);
create policy "insert own stress_logs" on stress_logs for insert with check (auth.uid() = user_id);
create policy "update own stress_logs" on stress_logs for update using (auth.uid() = user_id);
create policy "delete own stress_logs" on stress_logs for delete using (auth.uid() = user_id);

-- study_sessions policies
create policy "select own study_sessions" on study_sessions for select using (auth.uid() = user_id);
create policy "insert own study_sessions" on study_sessions for insert with check (auth.uid() = user_id);
create policy "update own study_sessions" on study_sessions for update using (auth.uid() = user_id);
create policy "delete own study_sessions" on study_sessions for delete using (auth.uid() = user_id);

-- planner_events policies
create policy "select own planner_events" on planner_events for select using (auth.uid() = user_id);
create policy "insert own planner_events" on planner_events for insert with check (auth.uid() = user_id);
create policy "update own planner_events" on planner_events for update using (auth.uid() = user_id);
create policy "delete own planner_events" on planner_events for delete using (auth.uid() = user_id);
